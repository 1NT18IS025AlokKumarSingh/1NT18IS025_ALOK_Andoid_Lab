package com.example.alok_ka_app;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.net.Inet4Address;

public class MainActivity extends AppCompatActivity {
    String TAG = "MainActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "Activity1 onCreate called");
        setContentView(R.layout.activity_main);
        EditText n1 = findViewById(R.id.num1);
        EditText n2 = findViewById(R.id.num2);
        Button add = findViewById(R.id.add);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int num1 = Integer.parseInt(n1.getText().toString());
                int num2 = Integer.parseInt(n2.getText().toString());
                int result = num1 + num2;
                String answer = Integer.toString(result);
                Intent intent = new Intent(getApplicationContext(), MainActivity2.class);
                intent.putExtra("ans", answer);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "Activity1 onStart called ");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "Activity1 onResume called ");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "Activity1 onPause called ");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "Activity1 onStop called");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "Activity1 onDestroy called");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(TAG, "Activity1 onRestart called");
    }
}