package com.example.alok_ka_app;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.content.Intent;

public class MainActivity2 extends AppCompatActivity {
    String TAG = "MainActivity2";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "Activity2 onCreate called");
        setContentView(R.layout.activity_main2);
        TextView result = (TextView)findViewById(R.id.textView);
        Intent intent = getIntent();
        String ans = intent.getStringExtra("ans");
        result.setText(ans);
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "Activity2 onStart called ");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "Activity2 onResume called ");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "Activity2 onPause called ");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "Activity2 onStop called");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "Activity2 onDestroy called");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(TAG, "Activity2 onRestart called");
    }
}