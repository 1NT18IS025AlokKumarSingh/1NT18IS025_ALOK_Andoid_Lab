package com.example.media_player;

import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView mediaPlayer;
    TextView songName;
    Button play;
    Button pause;
    Button forward;
    Button rewind;
    Button stop;
    Button restart;
    int startTime = 0;
    int stopTime = 0;
    int seek = 5000;
    MediaPlayer currMediaPlayer, newMediaPlayer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}